import numpy as np
import pandas as pd

# Read the data from a csv file.
data = pd.read_csv('./train.csv')

# What are the columns that have missing values, indicated by a '?'.
missing_columns = []
for c in data.columns:
  num_non = data[c].isin(['?']).sum()
  if num_non > 0:
    missing_columns.append(c)

# To keep things simple, we will discard the rows with missing values.
for c in data.columns:
  mask = [val != '?' for val in list(data[c])]
  data = data[mask]

# We discarded a small fraction of examples, we still have a lot of examples.
print("""The shape of the data matrix after dropping examples with missing values is ({}, {})""".format(data.shape[0], data.shape[1]))

# These are the discrete features.
discrete_features = ['workclass', 'race', 'education', 'marital-status',
    'occupation', 'relationship', 'gender', 'native-country']

# We convert all discrete features to numerical using one-hot encoding.
data = pd.get_dummies(data, columns=discrete_features)
print("""The shape of the data matrix after one-hot encoding is ({}, {})""".format(data.shape[0], data.shape[1]))

# Get the features and incomes as numpy arrays.
y = data.loc[:, 'income'].as_matrix()
X = data.drop('income', axis=1).as_matrix()
