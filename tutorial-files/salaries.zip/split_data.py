import numpy as np
import pandas as pd

# Read the data from a csv file.
data = pd.read_csv('./adult.csv')

# What are the columns that have missing values, indicated by a '?'.
missing_columns = []
for c in data.columns:
  num_non = data[c].isin(['?']).sum()
  if num_non > 0:
    missing_columns.append(c)
    print('Percentage of rows with missing values for {} is {:.2f}'.format(c,
      (100.0 * num_non) / data.shape[0]))

# To keep things simple, we will discard the rows with missing values.
for c in data.columns:
  mask = [val != '?' for val in list(data[c])]
  data = data[mask]

# We discarded a small fraction of examples, we still have a lot of examples.
print("""The shape of the data matrix after dropping examples with missing values is ({}, {})""".format(data.shape[0], data.shape[1]))

# These are the discrete features.
discrete_features = ['workclass', 'race', 'education', 'marital-status',
    'occupation', 'relationship', 'gender', 'native-country']

# We convert all discrete features to numerical using one-hot encoding.
# data = pd.get_dummies(data, columns=discrete_features)
# print("""The shape of the data matrix after one-hot encoding is ({}, {})""".format(data.shape[0], data.shape[1]))

idx = np.arange(data.shape[0])
np.random.shuffle(idx)
num = 10000
test_idx, train_idx = idx[:num], idx[num:]
df_train = data.iloc[train_idx]
df_train.to_csv('train.csv', index=False)
df_test = data.iloc[test_idx]
df_X = df_test.drop(['income'], axis=1)
df_y = df_test[['income']]
df_X.to_csv('test.csv', index=False)
df_y.to_csv('test_labels.csv', index=False)
