import csv
import numpy as np
from sklearn.tree import DecisionTreeClassifier

train_X = np.load("data/AlexNet_train_X.npy")
train_y = np.load("data/AlexNet_train_y.npy")
test_X = np.load("data/AlexNet_test_X.npy")

clf = DecisionTreeClassifier()
clf.fit(train_X, train_y)

pred_y = clf.predict(test_X)

with open('predictions.csv', 'w') as preds:
    writer = csv.writer(preds, lineterminator='\n')
    for p in pred_y:
        writer.writerow([p])
