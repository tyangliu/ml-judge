import numpy as np
import struct

def read_labels(filename):
  """
  Return the labels in the file as a numpy array.

  e.g., read_labels(train-labels.idx1-ubyte)
  """
  with open(filename, 'rb') as lbls:
    magic, num = struct.unpack(">II", lbls.read(8))
    lbl = np.fromfile(lbls, dtype=np.int8)

  return lbl

def read_images(filename, num_images):
  """
  Return the images in the file as a numpy array.

  e.g., read_images(train-images.idx3-ubyte)
  """
  with open(filename, 'rb') as imgs:
    magic, num, rows, cols = struct.unpack(">IIII", imgs.read(16))
    img = np.fromfile(imgs, dtype=np.uint8)
    img = img.reshape(num, rows, cols)

  return img

def dump_labels(labels, filename):
  """
  Dump the labels (given as a numpy array), to a CSV file.
  """
  with open(filename, "w+") as f:
    f.writelines(["%d\n" % label for label in labels])

def main():
  train_images = read_images("train-images.idx3-ubyte", 60000)
  train_labels = read_labels("train-labels.idx1-ubyte")
  test_images = read_images("t10k-images.idx3-ubyte", 10000)

if __name__ == '__main__':
  main()
